package CG510_APR_Support_v1.services;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2018-01-23 07:21:15 CET
// -----( ON-HOST: itsbebelsp00272.jnj.com

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Calendar;
import com.softwareag.util.IDataMap;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import com.webmethods.portal.bizPolicy.IContext;
import com.webmethods.portal.bizPolicy.biz.IBizPolicyManager;
import com.webmethods.portal.bizPolicy.biz.IBizPolicyNames;
import com.webmethods.portal.bizPolicy.biz.dir.IDirSystemBizPolicy;
import com.webmethods.portal.bizPolicy.biz.dir.IPrincipalBizPolicy;
import com.webmethods.portal.bizPolicy.impl.ContextFactory;
import com.webmethods.portal.service.dir.IDirPrincipal;
import com.webmethods.portal.service.dir.IDirPrincipalList;
import com.webmethods.portal.service.dir.IDirSystem;
import com.webmethods.portal.service.dir.impl.DirPrincipalListView;
import com.webmethods.portal.system.PortalSystem;
import com.webmethods.portal.system.IURI;
import com.webmethods.sc.directory.DirectorySystemFactory;
import com.webmethods.sc.directory.IDirectoryGroup;
import com.webmethods.sc.directory.IDirectoryPrincipal;
import com.webmethods.sc.directory.IDirectorySession;
import com.webmethods.sc.directory.IDirectoryUser;
import com.webmethods.sc.directory.IDirectoryRole;
import com.wm.data.IData;
import com.wm.data.IDataCursor;
import com.wm.data.IDataUtil;
import com.wm.lang.ns.NSName;
import com.webmethods.portal.mech.IMechanicsManager;
import com.webmethods.portal.mech.dir.IPrincipalMechanics;
import com.webmethods.portal.service.global.IGlobalProvider;
// --- <<IS-END-IMPORTS>> ---

public final class javaservices

{
	// ---( internal utility methods )---

	final static javaservices _instance = new javaservices();

	static javaservices _newInstance() { return new javaservices(); }

	static javaservices _cast(Object o) { return (javaservices)o; }

	// ---( server methods )---




	public static final void readGroupUsers (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(readGroupUsers)>> ---
		// @sigtype java 3.5
		// [i] field:0:required roleName
		// [o] field:1:required roleUsers
		// pipeline
		String[]	roleUsers = new String[1];
		//roleUsers[0] = "roleUsers";
		try{
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	roleName = IDataUtil.getString( pipelineCursor, "roleName" );
		pipelineCursor.destroy();
		
		IContext context = ContextFactory.acquireContext(true);
		IBizPolicyManager policyManager = (IBizPolicyManager) PortalSystem
		             .getBizPolicyProvider();
		 
		IDirSystemBizPolicy dirSystemPolicy = (IDirSystemBizPolicy) policyManager
		             .getBizPolicy(IBizPolicyNames.DIRECTORY_SYSTEM);
		IPrincipalBizPolicy princBizPolicy = (IPrincipalBizPolicy) policyManager
		             .getBizPolicy(IBizPolicyNames.PRINCIPAL);
		//IDirPrincipal principal = dirSystemPolicy.lookupPrincipalByID(context,
		       // userID, IDirSystem.TYPE_USER);
		IDirPrincipalList listOfroles = getRoleOrGroupUsers(context,dirSystemPolicy,princBizPolicy, roleName);
		roleUsers = new String[listOfroles.size()];
		for (int i = 0; i < roleUsers.length; i++) {
			roleUsers[i] = ((IDirPrincipal) listOfroles.get(i)).getName();
			//roleUsers[i] = ((IDirPrincipal) listOfroles.get(i))
		}
		}catch(Exception e){
		   throw new ServiceException(e.getMessage());
		}
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		
		IDataUtil.put( pipelineCursor_1, "roleUsers", roleUsers );
		pipelineCursor_1.destroy();
		
			
		// --- <<IS-END>> ---

                
	}



	public static final void readMWSRoles (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(readMWSRoles)>> ---
		// @sigtype java 3.5
		// [i] field:0:required username
		// [o] field:1:required roles
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	username = IDataUtil.getString( pipelineCursor, "username" );
		pipelineCursor.destroy();
		
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		try{		
		String[] roles = getAllRoles(username);
		
		IDataUtil.put( pipelineCursor_1, "roles", roles );
		pipelineCursor_1.destroy();
		}catch(Exception e){
			new ServiceException(e.getMessage());
		}
		
			
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	private static IDirPrincipalList getRoleOrGroupUsers(IContext context, IDirSystemBizPolicy dirSystemPolicy,
			IPrincipalBizPolicy princBizPolicy, String roleName) throws Exception {
		
	
		IData log = IDataFactory.create();
			IDataCursor logCursor = log.getCursor();
			IDataUtil.put(logCursor, "message","GetRoleOrGroupUsers : "+roleName);
			NSName ns= NSName.create("pub.flow:debugLog");
			try{
			Service.doInvoke(ns, log);
		logCursor.destroy();
			}
			catch(Exception e1)
			{
			}
	
		// retrieve the role
		IDirPrincipal role = dirSystemPolicy.lookupPrincipalByID(context, roleName, IDirSystem.TYPE_ROLE);
		// retrieve users in role
		if (null == role) {
			role = dirSystemPolicy.lookupPrincipalByID(context, roleName, IDirSystem.TYPE_GROUP);
			if (null == role) {
				return null;
			}
		}
		IDirPrincipalList roleUsers = princBizPolicy.getMembers(context, role.getDirectoryURI());
		return roleUsers;
	}
	
	
	private static Set<String> getSystemRoleUsers(IContext context, IDirSystemBizPolicy dirSystemPolicy,
			IPrincipalBizPolicy princBizPolicy, String roleName) throws Exception {
		IDirPrincipalList roleUsers = getRoleOrGroupUsers(context, dirSystemPolicy, princBizPolicy, roleName);
		if (roleUsers == null) {
			return null;
		}
		Set<String> results = new HashSet<String>();
		Iterator<IDirPrincipal> iterator = roleUsers.iterator();
		while (iterator.hasNext()) {
	
			String name = iterator.next().getName();
			Set<String> systemRoleUsers = getSystemRoleUsers(context, dirSystemPolicy, princBizPolicy, name);
			if (systemRoleUsers != null) {
				results.addAll(systemRoleUsers);
			} else {
				results.add(name);
			}
		}
		return results;
	}
	
	
	private static String[] getAllRoles(String username) throws Exception {
	
		IContext context = ContextFactory.acquireContext(true);
		IBizPolicyManager policyManager = (IBizPolicyManager) PortalSystem
				.getBizPolicyProvider();
	
		IDirSystemBizPolicy dirSystemPolicy = (IDirSystemBizPolicy) policyManager
				.getBizPolicy(IBizPolicyNames.DIRECTORY_SYSTEM);
		IPrincipalBizPolicy principalPolicy = (IPrincipalBizPolicy) policyManager
				.getBizPolicy(IBizPolicyNames.PRINCIPAL);
		String[] roles = null;
		// retrieve the user
		IDirPrincipal principal = dirSystemPolicy.lookupPrincipalByID(context,
				username, IDirSystem.TYPE_USER);
		if (principal != null) {
			// retrieve the roles for the user
			IDirPrincipalList listOfroles = principalPolicy.getRoleMembership(
					context, principal.getDirectoryURI());
	
			roles = new String[listOfroles.size()];
			for (int i = 0; i < listOfroles.size(); i++) {
				String role = ((IDirPrincipal) listOfroles.get(i)).getName();
				roles[i] = role;
			}
		}
		return roles;
	}
		
	// --- <<IS-END-SHARED>> ---
}

