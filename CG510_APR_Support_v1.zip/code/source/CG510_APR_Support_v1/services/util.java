package CG510_APR_Support_v1.services;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2017-12-12 22:35:40 CET
// -----( ON-HOST: itsbebelsp00272.jnj.com

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
// --- <<IS-END-IMPORTS>> ---

public final class util

{
	// ---( internal utility methods )---

	final static util _instance = new util();

	static util _newInstance() { return new util(); }

	static util _cast(Object o) { return (util)o; }

	// ---( server methods )---




	public static final void getDates (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getDates)>> ---
		// @sigtype java 3.5
		// [o] field:0:required fromDate
		// [o] field:0:required toDate
		try{
		String fromDate="";
		String toDate="";
		toDate= new SimpleDateFormat("dd-MMM-yy").format(new Date());
		Calendar lastMonth = Calendar.getInstance();
		lastMonth.add(Calendar.MONTH, -1);
		fromDate= new SimpleDateFormat("dd-MMM-yy").format(lastMonth.getTime());
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "fromDate", fromDate );
		IDataUtil.put( pipelineCursor_1, "toDate", toDate );
		pipelineCursor_1.destroy();
		}catch(Exception e){
			throw new ServiceException(e.getMessage());
		}
			
		// --- <<IS-END>> ---

                
	}
}

