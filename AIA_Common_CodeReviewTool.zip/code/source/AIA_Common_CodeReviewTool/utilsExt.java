package AIA_Common_CodeReviewTool;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.util.JournalLogger;
import com.wm.app.b2b.server.FlowManager;
import com.wm.app.b2b.server.BaseService;
import com.wm.app.b2b.server.ServiceSetupException;
import com.wm.app.b2b.server.ns.NSNodeUtil;
import com.wm.app.b2b.server.ns.Namespace;
import java.util.ArrayList;
import java.util.List;
import com.softwareag.util.IDataMap;
import com.wm.lang.flow.FlowElement;
import com.wm.lang.flow.FlowInvoke;
import com.wm.lang.flow.FlowMap;
import com.wm.lang.flow.FlowMapInvoke;
import com.wm.lang.flow.FlowMapSet;
import com.wm.lang.flow.FlowRoot;
import com.wm.lang.flow.FlowSequence;
import com.wm.lang.flow.IDataWmPathProcessor;
import com.wm.lang.ns.NSName;
import com.wm.lang.ns.NSNode;
import com.wm.lang.ns.NSPackage;
import com.wm.lang.ns.WmPathItem;
// --- <<IS-END-IMPORTS>> ---

public final class utilsExt

{
	// ---( internal utility methods )---

	final static utilsExt _instance = new utilsExt();

	static utilsExt _newInstance() { return new utilsExt(); }

	static utilsExt _cast(Object o) { return (utilsExt)o; }

	// ---( server methods )---




	public static final void getGlobVarUsage (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getGlobVarUsage)>> ---
		// @sigtype java 3.5
		// [i] field:0:required serviceName
		// [i] field:0:required searchString
		// [o] field:0:required updateCount
		// [o] field:0:required error
		IDataMap idm = new IDataMap(pipeline);
		String serviceName = idm.getAsString("serviceName");
		String searchString = idm.getAsString("searchString");
		ArrayList<String> steps = new ArrayList<String>();
		
		BaseService baseService = Namespace.getService(NSName.create(serviceName));
		//idm.put("service", baseService);
		if (baseService != null)
		{
			try {
					IData serviceSteps = baseService.getAsData();
					IDataCursor idc = serviceSteps.getCursor();
					//services d1 = new services();
					if (baseService.getServiceType().toString().equals("flow/default")) 
					{
						while (idc.next()) 
						{
							if (idc.getKey().toString() == "flow") 
							{
								FlowRoot fr = (FlowRoot) idc.getValue();
								//com.wm.util.JournalLogger.log(3, 90, 3, "fr obtained");
								FlowElement fe[] = fr.getNodes();
								//com.wm.util.JournalLogger.log(3, 90, 3, "fr.getNodes");
								if(fe!=null && fe.length>0)
								{
									for (FlowElement flowElement : fe) 
									{ 						
										//com.wm.util.JournalLogger.log(3, 90, 3, "in first for");
										getMapSets(flowElement,searchString,steps);
									}
								}
							}
						}
						
						idc.destroy();
						idm.put("varUsage", steps.toArray(new String[steps.size()]));
					} 
					else 
					{
						idm.put("error", serviceName + " is not a flow service.");
					}
				} 
			catch (Exception e) 
			{
				e.printStackTrace();
				com.wm.util.JournalLogger.log(3, 90, 3, e);
				idm.put("error", e.getMessage());
			}
		} 
		else
		{
			idm.put("error", "Unable to fetch flow service " + serviceName);
		}
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	
	public static void getMapSets(FlowElement flowElement, String searchString, List steps) 
	 {
		if (flowElement.getFlowType().equals("SEQUENCE")
				|| flowElement.getFlowType().equals("BRANCH")
				|| flowElement.getFlowType().equals("LOOP")
				|| flowElement.getFlowType().equals("RETRY")) 
		{
			//JournalLogger.log(3, 90, 3, "in if for sblr");
			if(flowElement.getNodes()!=null && flowElement.getNodes().length>0)
			{
				for (FlowElement flowElement2 : flowElement.getNodes())
				{
					//JournalLogger.log(3,90,3, flowElement2.getDisplayType());
					
					getMapSets(flowElement2, searchString, steps);
					
					/*	recursively calling the getFlowStepName method in case of sequences, 
					branches, loops and retries as these steps
					can have more child steps*/
				}
			}
		} 
		else 
		{
			if (flowElement.getFlowType().equals("MAP")) 
			{				
				FlowMap flowMap = (FlowMap) flowElement;
				if(flowMap.getSetMaps()!=null && flowMap.getSetMaps().length >0 )
				{
					for (FlowMapSet mapset : flowMap.getSetMaps()) 
					{
						if (mapset.getInput().toString().equals(searchString)) 
						{JournalLogger.log(3,90,3,"Hardcoded value \""+mapset.getInput().toString()+"\" at MAP ");
							steps.add(flowElement.getFlowType().toString()+"("+flowElement.getComment()+")");
														
						}
					}
				}
				
				
				if(flowMap.getInvokeMaps()!=null &&flowMap.getInvokeMaps().length>0){
					//System.out.println(flowMap.getInvokeMaps().toString());
					for(FlowMapInvoke transformers : flowMap.getInvokeMaps()){
						
						if(transformers.getInputMap().getSetMaps() != null && transformers.getInputMap().getSetMaps().length>0){
							for (FlowMapSet mapset : transformers.getInputMap().getSetMaps()) 
							{
								if (mapset.getInput().toString().equals(searchString)) 
								{
									steps.add(flowElement.getFlowType().toString()+"("+flowElement.getComment()+")");
									JournalLogger.log(3,90,3,"Hardcoded value \""+mapset.getInput().toString()+"\" at  MAP Transformer");
									
								}
							}
							
							
						}
					}
				}
				
				
				
			}
			if (flowElement.getFlowType().equals("INVOKE")) 
			{				
				FlowInvoke flowInvoke = (FlowInvoke) flowElement;
				//JournalLogger.log(3, 90, 3, flowInvoke.getService().toString());
				//JournalLogger.log(3, 90, 3, flowInvoke.getInputMap());
				if(flowInvoke.getInputMap() != null){
				if(flowInvoke.getInputMap().getSetMaps()!=null && flowInvoke.getInputMap().getSetMaps().length>0)
				{
					for (FlowMapSet mapset : flowInvoke.getInputMap().getSetMaps())
					{
						if (mapset.getInput().toString().equals(searchString))
						{
							steps.add(flowElement.getFlowType().toString()+"("+flowElement.getComment()+")");
							JournalLogger.log(3,90,3,"Hardcoded value \""+mapset.getInput().toString()+"\" at INVOKE ");
						}
					}
				}
				}
			}
		}
	}
	// --- <<IS-END-SHARED>> ---
}

