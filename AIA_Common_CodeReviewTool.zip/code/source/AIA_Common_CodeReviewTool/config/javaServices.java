package AIA_Common_CodeReviewTool.config;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.util.JournalLogger;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;
// --- <<IS-END-IMPORTS>> ---

public final class javaServices

{
	// ---( internal utility methods )---

	final static javaServices _instance = new javaServices();

	static javaServices _newInstance() { return new javaServices(); }

	static javaServices _cast(Object o) { return (javaServices)o; }

	// ---( server methods )---




	public static final void getProperty (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getProperty)>> ---
		// @sigtype java 3.5
		// [i] field:0:required propertyKey
		// [o] field:0:required propertyValue
		String propertyKey = IDataUtil.getString(pipeline.getCursor(), "propertyKey");
		
		
		if(propertyKey!=null && !propertyKey.trim().equals("")){
			
			if(properties.isEmpty()){
				JournalLogger.log(3,90,3,"properties are not loaded. Loading properties from file");
				loadProperties(pipeline);
				IDataUtil.put(pipeline.getCursor(), "propertyValue",properties.get(propertyKey));
			}
			
			else {
				
				IDataUtil.put(pipeline.getCursor(), "propertyValue",properties.get(propertyKey));
			}
			
			
			
			
		
			
		}
		// --- <<IS-END>> ---

                
	}



	public static final void loadProperties (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(loadProperties)>> ---
		// @sigtype java 3.5
	try{
		InputStream inputFile = new FileInputStream("."+File.separator+"packages"+File.separator+"AIA_Common_CodeReviewTool"+File.separator+"config"+File.separator+"AIA_Common_CodeReviewTool.properties");
		JournalLogger.log(3,90,3,"Loading properties");
		properties.load(inputFile);
		JournalLogger.log(3,90,3,"Loaded properties");
		IDataUtil.put(pipeline.getCursor(), "properties", properties.toString());
			
	}
	catch(Exception e){
		e.printStackTrace();
		JournalLogger.log(3,90,3,"Could not load properties file from ."+File.separator+"packages"+File.separator+"AIA_Common_CodeReviewTool"+File.separator+"config"+File.separator+"AIA_Common_CodeReviewTool.properties");
				
	}
	
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	static Properties properties = new Properties();
	// --- <<IS-END-SHARED>> ---
}

