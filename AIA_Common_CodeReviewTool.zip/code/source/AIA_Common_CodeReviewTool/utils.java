package AIA_Common_CodeReviewTool;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.lang.ns.NSName;
import com.softwareag.util.IDataMap;
import com.wm.app.b2b.server.BaseService;
import com.wm.app.b2b.server.ns.Namespace;
// --- <<IS-END-IMPORTS>> ---

public final class utils

{
	// ---( internal utility methods )---

	final static utils _instance = new utils();

	static utils _newInstance() { return new utils(); }

	static utils _cast(Object o) { return (utils)o; }

	// ---( server methods )---




	public static final void checkCamelCase (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(checkCamelCase)>> ---
		// @sigtype java 3.5
		// [i] field:0:required inputString
		// [o] object:0:required isCameCased?
		String inputString = IDataUtil.getString(pipeline.getCursor(), "inputString");
		
		//Not checking for exact camelcase as string in all lower case is also valid naming
		String camelCasePattern = "([a-z]+[A-Z]*\\w+)+";
		
		
		if (inputString != null && !inputString.trim().equals("")) {
		
			IDataUtil.put(pipeline.getCursor(), "isCamelCased?", inputString.matches(camelCasePattern));
		
		}
		
		
		
		
			
		// --- <<IS-END>> ---

                
	}



	public static final void getServiceType (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getServiceType)>> ---
		// @sigtype java 3.5
		// [i] field:0:required serviceName
		// [o] field:0:required serviceType
		IDataMap idm = new IDataMap(pipeline);
		String serviceName = idm.getAsNonEmptyString("serviceName");
		String serviceType=null;
		try {
			BaseService service = Namespace.getService(NSName.create(serviceName));
		
			if (service.getServiceType().isFlowService()) {
		
				serviceType = "flow";
			} else {
				if (service.getServiceType().isJavaService()) {
		
					serviceType = "java";
				}
				
				else {
					
					serviceType = service.getServiceType().getType();
					
				}
			}
		} catch (Exception e) {
			idm.put("error", e.getMessage());	
			serviceType = "unknown";
		}
		
		finally{
			
			idm.put("serviceType", serviceType);
		}
		// --- <<IS-END>> ---

                
	}
}

