package AIA_Common_CodeReviewTool.core;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.lang.flow.FlowElement;
import com.wm.lang.flow.FlowInvoke;
import com.wm.lang.flow.FlowMap;
import com.wm.lang.flow.FlowMapCopy;
import com.wm.lang.flow.FlowMapInvoke;
import com.wm.lang.flow.FlowMapSet;
import com.wm.lang.flow.FlowRoot;
import com.wm.lang.ns.NSName;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashSet;
import com.softwareag.util.IDataMap;
import com.sun.org.apache.xml.internal.utils.NameSpace;
import com.wm.app.b2b.server.BaseService;
import com.wm.app.b2b.server.FlowManager;
import com.wm.app.b2b.server.PackageManager;
import com.wm.app.b2b.server.ns.Namespace;
// --- <<IS-END-IMPORTS>> ---

public final class javaServices

{
	// ---( internal utility methods )---

	final static javaServices _instance = new javaServices();

	static javaServices _newInstance() { return new javaServices(); }

	static javaServices _cast(Object o) { return (javaServices)o; }

	// ---( server methods )---




	public static final void checkVariableNaming (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(checkVariableNaming)>> ---
		// @sigtype java 3.5
		// [i] field:0:required serviceName
		// [o] field:1:required vars
		System.out.println("***************************");
		String camelCasePattern = "([a-z]+[A-Z]*\\w+)+";
		IDataMap idm = new IDataMap(pipeline);
		String serviceName = idm.getAsString("serviceName");
		BaseService baseService = Namespace.getService(NSName.create(serviceName));// Creating
																					// a
																					// baseService
																					// object
																					// to
																					// get
																					// a
																					// handle
																					// to
																					// the
																					// flow
																					// service.
		ArrayList<String> varsList = new ArrayList<String>();
		if (baseService != null) {
			try {
		
				IData serviceSteps = baseService.getAsData();
				IDataCursor idc = serviceSteps.getCursor();
				if (baseService.getServiceType().toString().equals("flow/default")) {
		
					while (idc.next()) {
		
						if (idc.getKey().toString() == "flow") {
							FlowRoot fr = (FlowRoot) idc.getValue();
							FlowElement fe[] = fr.getNodes();
							if (fe != null && fe.length > 0) {
								for (FlowElement flowElement : fe) {
									getFlowStepName(flowElement, varsList);
		
								}
							}
						}
					}
		
					idc.destroy();
					ArrayList<String> varsWithWrongNames = new ArrayList<String>();
					for (String varName : varsList) {
		
						if (varName != null && !varName.trim().equals("")) {
		
							if (!varName.contains("[")) {
		
								if (!varName.matches(camelCasePattern)) {
		
									varsWithWrongNames.add(varName);
		
								}
							}
		
						}
		
					}
					
					/*removing the duplicates from the list*/
					
					LinkedHashSet <String> hashSet = new LinkedHashSet<>(varsWithWrongNames);
					ArrayList<String> varsWithWrongNamesDeDuplicated = new ArrayList<String>(hashSet);
					idm.put("vars", varsWithWrongNamesDeDuplicated.toArray(new String[varsWithWrongNamesDeDuplicated.size()]));
		
				}
		
				else {
		
					idm.put("error", serviceName + " is not a flow service.");
				}
			} catch (Exception e) {
		
				e.printStackTrace();
				com.wm.util.JournalLogger.log(3, 90, 3, e);
				idm.put("error", e.getMessage());
			}
		
		} else {
		
			idm.put("error", "Unable to fetch service " + serviceName);
		}
			
		// --- <<IS-END>> ---

                
	}



	public static final void getPackageDependencies (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getPackageDependencies)>> ---
		// @sigtype java 3.5
		// [i] field:0:required serviceName
		// [o] field:1:required dependencies
		String serviceName = IDataUtil.getString(pipeline.getCursor(), "serviceName");
		NSName nsName = NSName.create(serviceName);
		IData pkgDependenciesIData = PackageManager.getPackage(Namespace.getBaseService(nsName).getPackageName()).getProperties();
		
		IDataCursor idc = pkgDependenciesIData.getCursor();
		
		IData requiresIdata = IDataUtil.getIData(idc, "requires");
		ArrayList<String> pkgDependenciesList = new ArrayList<String>();
		if(requiresIdata!=null){
			IDataCursor idc2 = IDataUtil.getIData(idc, "requires").getCursor();
			
			while (idc2.next()) {
				pkgDependenciesList.add(idc2.getKey());
			
			}
			idc.destroy();
			idc2.destroy();
		}
		
		IDataUtil.put(pipeline.getCursor(), "dependencies",
				pkgDependenciesList.toArray(new String[pkgDependenciesList.size()]));
			
		// --- <<IS-END>> ---

                
	}



	public static final void getPipelineDebugOption (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getPipelineDebugOption)>> ---
		// @sigtype java 3.5
		// [i] field:0:required service
		// [o] field:0:required pipelineDebugOption
		// [o] field:0:required Error
		IDataMap idm = new IDataMap(pipeline);
		String serviceName = idm.getAsString("service");
		Integer pipelineDebugOption = null;
		try {
			NSName serviceNamespace = NSName.create(serviceName);
			BaseService baseService = Namespace.getService(serviceNamespace);
			pipelineDebugOption = baseService.getPipelineOption();
			//idm.put("baseService", baseService.getAsData());
		} catch (Exception e) {
			
			idm.put("Error", e.getMessage());
		}
		
		idm.put("pipelineDebugOption", pipelineDebugOption.toString());
			
		// --- <<IS-END>> ---

                
	}



	public static final void getServiceACL (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getServiceACL)>> ---
		// @sigtype java 3.5
		// [i] field:0:required serviceName
		// [o] field:0:required acl
		String serviceName = IDataUtil.getString(pipeline.getCursor(), "serviceName");
		
		NSName nsName = NSName.create(serviceName);
		IDataUtil.put(pipeline.getCursor(), "acl", Namespace.getBaseService(nsName).getAclGroup());
		// --- <<IS-END>> ---

                
	}



	public static final void getServiceComments (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getServiceComments)>> ---
		// @sigtype java 3.5
		// [i] field:0:required serviceName
		// [o] field:0:required serviceComments
		String serviceName = IDataUtil.getString(pipeline.getCursor(), "serviceName");
		NSName nsName = NSName.create(serviceName);
		
		IDataUtil.put(pipeline.getCursor(), "serviceComments", Namespace.getBaseService(nsName).getComment());
			
		// --- <<IS-END>> ---

                
	}



	public static final void getServiceStatelessProperty (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getServiceStatelessProperty)>> ---
		// @sigtype java 3.5
		// [i] field:0:required serviceName
		// [o] field:0:required isStateLess
		String serviceName = IDataUtil.getString(pipeline.getCursor(), "serviceName");
		NSName nsName = NSName.create(serviceName);
		IDataUtil.put(pipeline.getCursor(), "isStateLess", Namespace.getBaseService(nsName).isStateless());
			
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	
	public static void getFlowStepName(FlowElement flowElement, ArrayList<String> varsList ) 
	{
		if (flowElement.getFlowType().equals("SEQUENCE") || flowElement.getFlowType().equals("BRANCH")
				|| flowElement.getFlowType().equals("LOOP") || flowElement.getFlowType().equals("RETRY")) {
			if (flowElement.getNodes() != null && flowElement.getNodes().length > 0) {
				for (FlowElement flowElement2 : flowElement.getNodes()) {
	
					getFlowStepName(flowElement2, varsList);
					/*
					 * recursively calling the getFlowStepName method in case of
					 * sequences, branches, loops and retries as these steps can
					 * have more child steps
					 */
	
				}
			}
		} else {
	
			if (flowElement.getFlowType().equals("INVOKE")) {
	
				FlowInvoke flowInvoke = (FlowInvoke) flowElement;
			
				if (flowInvoke.getInputMap() != null) {
					if (flowInvoke.getInputMap().getCopyMaps() != null) {
						for (FlowMapCopy fmc : flowInvoke.getInputMap().getCopyMaps()) {
							if (fmc != null) {
								for (String s : fmc.getMapFrom().split("/")) {
	
									if (s != null && !s.trim().equals("")) {
	
										String varName = s.substring(0, s.indexOf(";"));
										varsList.add(varName);
	
									}
	
								}
								
								//disabling mapTo variable names
								/*for (String s : fmc.getMapTo().split("/")) {
									
									if (s != null && !s.trim().equals("")) {
	
										String varName = s.substring(0, s.indexOf(";"));
										varsList.add(varName);
	
									}
	
								}*/
							}
	
						}
					}
	
					//disabling set map inputs in invoke
					/*if (flowInvoke.getInputMap().getSetMaps() != null) {
						for (FlowMapSet fms : flowInvoke.getInputMap().getSetMaps()) {
							if (fms != null && fms.getField() != null) {
								for (String s : fms.getField().split("/")) {
	
									if (s != null && !s.trim().equals("")) {
	
										String varName = s.substring(0, s.indexOf(";"));
										varsList.add(varName);
	
									}
	
								}
							}
	
						}
					}*/
	
				}
	
			} else {
	
				if (flowElement.getFlowType().equals("MAP")) {
	
					FlowMap fm = (FlowMap) flowElement;
	
					if (fm.getCopyMaps() != null) {
						for (FlowMapCopy fmc : fm.getCopyMaps()) {
	
							for (String s : fmc.getMapFrom().split("/")) {
	
								if (s != null && !s.trim().equals("")) {
	
									String varName = s.substring(0, s.indexOf(";"));
									varsList.add(varName);
								}
	
							}
	
						}
	
					}
	
					if (fm.getSetMaps() != null) {
	
						for (FlowMapSet mapSet : fm.getSetMaps()) {
	
							for (String s : mapSet.getField().split("/")) {
	
								if (s != null && !s.trim().equals("")) {
	
									String varName = s.substring(0, s.indexOf(";"));
									varsList.add(varName);
								}
	
							}
						}
	
					}
					
					if(fm.getInvokeMaps() !=null && fm.getInvokeMaps().length>0){
						
						for(FlowMapInvoke transformer : fm.getInvokeMaps()){
							
								if(transformer.getInputMap() != null && transformer.getInputMap().getCopyMaps() != null){
									
									for (FlowMapCopy fmc : transformer.getInputMap().getCopyMaps()) {
										
										for (String s : fmc.getMapFrom().split("/")) {
				
											if (s != null && !s.trim().equals("")) {
				
												String varName = s.substring(0, s.indexOf(";"));
												varsList.add(varName);
											}
				
										}
				
									}
									
								}
							
						}
						
						
					}
	
				}
	
			}
		}
	}
	
	
		
	// --- <<IS-END-SHARED>> ---
}

