package AIA_Common_CodeReviewTool.core;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.lang.flow.FlowElement;
import com.wm.lang.flow.FlowInvoke;
import com.wm.lang.flow.FlowMap;
import com.wm.lang.flow.FlowMapInvoke;
import com.wm.lang.flow.FlowMapSet;
import com.wm.lang.flow.FlowRoot;
import com.wm.lang.ns.NSName;
import com.wm.util.JournalLogger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import com.softwareag.util.IDataMap;
import com.wm.app.b2b.server.BaseService;
import com.wm.app.b2b.server.FlowManager;
import com.wm.app.b2b.server.ns.Namespace;
// --- <<IS-END-IMPORTS>> ---

public final class notAllowedServicesCheck

{
	// ---( internal utility methods )---

	final static notAllowedServicesCheck _instance = new notAllowedServicesCheck();

	static notAllowedServicesCheck _newInstance() { return new notAllowedServicesCheck(); }

	static notAllowedServicesCheck _cast(Object o) { return (notAllowedServicesCheck)o; }

	// ---( server methods )---




	public static final void checkNotAllowedService (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(checkNotAllowedService)>> ---
		// @sigtype java 3.5
		// [i] field:0:required serviceName
		// [i] field:1:required servicesNotAllowed
		// [o] field:1:required notAllowedServicesPresent
		IDataMap idm = new IDataMap(pipeline);
		String serviceName = idm.getAsString("serviceName");
		
		servicesNotAllowed = new ArrayList<String>( Arrays.asList(idm.getAsStringArray("servicesNotAllowed")));
		ArrayList<String> notAllowedServicesUsed = new ArrayList<String>();
		BaseService baseService = Namespace.getService(NSName.create(serviceName));//Creating a baseService object to get a handle to the flow service.
		
		if(baseService!=null){
		try {
			
			IData serviceSteps = baseService.getAsData();   
			IDataCursor idc = serviceSteps.getCursor();
			
			if (baseService.getServiceType().toString().equals("flow/default")) {
		
				while (idc.next()) {
		
					if (idc.getKey().toString() == "flow") {
						FlowRoot fr = (FlowRoot) idc.getValue();
						FlowElement fe[] = fr.getNodes();
						if(fe!=null && fe.length>0){
						for (FlowElement flowElement : fe) {
							 getFlowStepName(flowElement,notAllowedServicesUsed,(ArrayList<String>) servicesNotAllowed);
							 
						}
						}
					}
				}
				
				idc.destroy();
				idm.put("notAllowedServicesPresent", notAllowedServicesUsed.toArray(new String[notAllowedServicesUsed.size()]));
			}
		
			else {
		
				idm.put("error", serviceName + " is not a flow service.");
			}
		} catch (Exception e) {
		
			e.printStackTrace();
			com.wm.util.JournalLogger.log(3,90,3,e );
			idm.put("error", e.getMessage());
		}
		
		}
		else{
			
			idm.put("error", "Unable to fetch service "+serviceName);
		}
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	static ArrayList<String> servicesNotAllowed;
	
	public static void getFlowStepName(FlowElement flowElement, ArrayList<String> notAllowedServicesUsed,
			ArrayList<String> notAllowedServices) {
		if (flowElement.getFlowType().equals("SEQUENCE") || flowElement.getFlowType().equals("BRANCH")
				|| flowElement.getFlowType().equals("LOOP") || flowElement.getFlowType().equals("RETRY")) {
			if (flowElement.getNodes() != null && flowElement.getNodes().length > 0) {
				for (FlowElement flowElement2 : flowElement.getNodes()) {
	
					getFlowStepName(flowElement2, notAllowedServicesUsed, notAllowedServices);
					/*
					 * recursively calling the getFlowStepName method in case of
					 * sequences, branches, loops and retries as these steps can
					 * have more child steps
					 */
	
				}
			}
		} else {
	
			if (flowElement.getFlowType().equals("INVOKE")) {
				FlowInvoke flowInvoke = (FlowInvoke) flowElement;
				String serviceName = flowInvoke.getService().getFullName();
	
				if (notAllowedServices.contains(serviceName)) {
	
					notAllowedServicesUsed.add(serviceName);
	
				}
				
					
			} if(flowElement.getFlowType().equals("MAP")) {
				
				FlowMap flowMap = (FlowMap) flowElement;
				if(flowMap.getInvokeMaps()!=null){
					
					for(FlowMapInvoke transformer : flowMap.getInvokeMaps()){
						
						String serviceName = transformer.getService().getFullName();
						if (notAllowedServices.contains(serviceName)) {
							
							notAllowedServicesUsed.add(serviceName);
			
						}
						
					}
					
				}
				// JournalLogger.log(3, 90, 3, "test2");
			}
		}
	}
	// --- <<IS-END-SHARED>> ---
}

