package AIA_Common_CodeReviewTool.core;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.lang.flow.FlowElement;
import com.wm.lang.flow.FlowRoot;
import com.wm.lang.flow.FlowSequence;
import com.wm.lang.ns.NSName;
import com.softwareag.util.IDataMap;
import com.wm.app.b2b.server.BaseService;
import com.wm.app.b2b.server.ns.Namespace;
// --- <<IS-END-IMPORTS>> ---

public final class checkTryCatchBlock

{
	// ---( internal utility methods )---

	final static checkTryCatchBlock _instance = new checkTryCatchBlock();

	static checkTryCatchBlock _newInstance() { return new checkTryCatchBlock(); }

	static checkTryCatchBlock _cast(Object o) { return (checkTryCatchBlock)o; }

	// ---( server methods )---




	public static final void checkTryCatchBlock (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(checkTryCatchBlock)>> ---
		// @sigtype java 3.5
		// [i] field:0:required serviceName
		// [o] field:0:required hasTryCatch
		IDataMap idm = new IDataMap(pipeline);
		String serviceName = idm.getAsString("serviceName");
		BaseService baseService = Namespace.getService(NSName.create(serviceName));//Creating a baseService object to get a handle to the flow service.
		StringBuffer tryCatchSequence = new StringBuffer();
		if(baseService!=null){
			try {
				
				IData serviceSteps = baseService.getAsData();   
				IDataCursor idc = serviceSteps.getCursor();
				
				if (baseService.getServiceType().toString().equals("flow/default")) {
			
					while (idc.next()) {
			
						if (idc.getKey().toString() == "flow") {
							FlowRoot fr = (FlowRoot) idc.getValue();
							FlowElement fe[] = fr.getNodes();
							if(fe!=null && fe.length>0){
									
								for(FlowElement flowElement : fe){
									
									if(flowElement!= null && flowElement.getFlowType().equals("SEQUENCE")){
										
										//System.out.println("in 1");						
										FlowSequence fs = (FlowSequence)flowElement;	
										//System.out.println("in 1--fs ExitOnProp value "+fs.getExitOn());
										if(fs.getExitOn()==1){
											tryCatchSequence.append("1");
											FlowElement[] childSeq1 = flowElement.getNodes();
											
											if (childSeq1 != null) {
		
												if (childSeq1[0] != null && childSeq1[0].getFlowType().equals("SEQUENCE")) {
		
													FlowSequence fsChildSeq1 = (FlowSequence) childSeq1[0];
													if (fsChildSeq1.getExitOn() == 0) {
														tryCatchSequence.append("0");
		
													}
												}
												
												if(childSeq1[1] != null && childSeq1[1].getFlowType().equals("SEQUENCE")){
													
													FlowSequence fsChildSeq1 = (FlowSequence) childSeq1[1];
													if (fsChildSeq1.getExitOn() == 2) {
														tryCatchSequence.append("2");
		
													}
													
												}
		
											}
											
										}
										
										
										
									}
									
								}
								
							}
						}
					}
			
					
					idc.destroy();
					
					//System.out.println("tryCatchSequence value="+tryCatchSequence);
					if(tryCatchSequence.toString().equals("102")){
						
						idm.put("hasTryCatch", "true");
						
					}
					else{
						
						idm.put("hasTryCatch", "false");
					}
				}
			
				else {
			
					idm.put("error", serviceName + " is not a flow service.");
				}
			} catch (Exception e) {
			
				e.printStackTrace();
				com.wm.util.JournalLogger.log(3,90,3,e );
				idm.put("error", e.getMessage());
			}
			
			}
			else{
				
				idm.put("error", "Unable to fetch service "+serviceName);
			}
		
		
		
			
		// --- <<IS-END>> ---

                
	}
}

