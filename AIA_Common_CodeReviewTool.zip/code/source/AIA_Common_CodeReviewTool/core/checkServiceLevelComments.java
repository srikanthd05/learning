package AIA_Common_CodeReviewTool.core;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.lang.flow.FlowElement;
import com.wm.lang.flow.FlowInvoke;
import com.wm.lang.flow.FlowRoot;
import com.wm.lang.ns.NSName;
import java.util.ArrayList;
import java.util.HashMap;
import com.softwareag.util.IDataMap;
import com.wm.app.b2b.server.BaseService;
import com.wm.app.b2b.server.ns.Namespace;
// --- <<IS-END-IMPORTS>> ---

public final class checkServiceLevelComments

{
	// ---( internal utility methods )---

	final static checkServiceLevelComments _instance = new checkServiceLevelComments();

	static checkServiceLevelComments _newInstance() { return new checkServiceLevelComments(); }

	static checkServiceLevelComments _cast(Object o) { return (checkServiceLevelComments)o; }

	// ---( server methods )---




	public static final void checkServiceLevelComments (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(checkServiceLevelComments)>> ---
		// @sigtype java 3.5
		// [i] field:0:required serviceName
		// [o] field:0:required TotalSteps
		// [o] field:0:required CommentedSteps
		IDataMap idm = new IDataMap(pipeline);
		String serviceName = idm.getAsString("serviceName");
		HashMap<String,Integer> stepsDetails = new HashMap<String,Integer>();
		stepsDetails.put("TotalSteps", 0);
		stepsDetails.put("CommentedSteps", 0);
		System.out.println("***");
		BaseService baseService = Namespace.getService(NSName.create(serviceName));//Creating a baseService object to get a handle to the flow service.
		if(baseService!=null){
		try {
			
			IData serviceSteps = baseService.getAsData();   
			IDataCursor idc = serviceSteps.getCursor();
			
			if (baseService.getServiceType().toString().equals("flow/default")) {
		
				while (idc.next()) {
		
					if (idc.getKey().toString() == "flow") {
						FlowRoot fr = (FlowRoot) idc.getValue();
						FlowElement fe[] = fr.getNodes();
						if(fe!=null && fe.length>0){
						for (FlowElement flowElement : fe) {
							 getFlowStepName(flowElement,stepsDetails);
							 
						}
						}
					}
				}
		
				
				idc.destroy();
				idm.put("TotalSteps", stepsDetails.get("TotalSteps").toString());
				idm.put("CommentedSteps", stepsDetails.get("CommentedSteps").toString());
				
			}
		
			else {
		
				idm.put("error", serviceName + " is not a flow service.");
			}
		} catch (Exception e) {
		
			e.printStackTrace();
			com.wm.util.JournalLogger.log(3,90,3,e );
			idm.put("error", e.getMessage());
		}
		
		}
		else{
			
			idm.put("error", "Unable to fetch service "+serviceName);
		}
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	public static void getFlowStepName(FlowElement flowElement, HashMap<String,Integer> stepsDetails) 
	{
		stepsDetails.put("TotalSteps", (stepsDetails.get("TotalSteps") + 1));
		if (flowElement.getComment() != null && !flowElement.getComment().equals("")) {
	
			stepsDetails.put("CommentedSteps", (stepsDetails.get("CommentedSteps") + 1));
		}
		if (flowElement.getFlowType().equals("SEQUENCE") || flowElement.getFlowType().equals("BRANCH")
				|| flowElement.getFlowType().equals("LOOP") || flowElement.getFlowType().equals("RETRY")) {
			if (flowElement.getNodes() != null && flowElement.getNodes().length > 0) {
				for (FlowElement flowElement2 : flowElement.getNodes()) {
	
					getFlowStepName(flowElement2, stepsDetails);
	
				}
			}
		}
	}
	// --- <<IS-END-SHARED>> ---
}

