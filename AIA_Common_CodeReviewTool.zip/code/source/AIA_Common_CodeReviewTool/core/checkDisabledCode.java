package AIA_Common_CodeReviewTool.core;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.lang.flow.FlowElement;
import com.wm.lang.flow.FlowInvoke;
import com.wm.lang.flow.FlowRoot;
import com.wm.lang.ns.NSName;
import com.softwareag.util.IDataMap;
import com.wm.app.b2b.server.BaseService;
import com.wm.app.b2b.server.ns.Namespace;
// --- <<IS-END-IMPORTS>> ---

public final class checkDisabledCode

{
	// ---( internal utility methods )---

	final static checkDisabledCode _instance = new checkDisabledCode();

	static checkDisabledCode _newInstance() { return new checkDisabledCode(); }

	static checkDisabledCode _cast(Object o) { return (checkDisabledCode)o; }

	// ---( server methods )---




	public static final void checkDisabledCode (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(checkDisabledCode)>> ---
		// @sigtype java 3.5
		// [i] field:0:required serviceName
		// [o] field:0:required hasDisabledCode
		System.out.println("*****************");
		IDataMap idm = new IDataMap(pipeline);
		String serviceName = idm.getAsString("serviceName");
		StringBuffer hasDisabledCode= new StringBuffer("0");
		BaseService baseService = Namespace.getService(NSName.create(serviceName));//Creating a baseService object to get a handle to the flow service.
		if(baseService!=null){
		try {
			
			IData serviceSteps = baseService.getAsData();   
			IDataCursor idc = serviceSteps.getCursor();
				if (baseService.getServiceType().toString().equals("flow/default")) {
		
					while (idc.next()) {
		
						if (idc.getKey().toString() == "flow") {
							FlowRoot fr = (FlowRoot) idc.getValue();
							FlowElement fe[] = fr.getNodes();
							if (fe != null && fe.length > 0) {
								for (FlowElement flowElement : fe) {
		
									getFlowStepName(flowElement, hasDisabledCode);
		
								}
							}
						}
					}
		
					idc.destroy();
					
					idm.put("hasDisabledCode", hasDisabledCode.toString().equals("0")?"false":"true");
		
				}
		
				else {
					idm.put("error", serviceName + " is not a flow service.");
				}
			} catch (Exception e) {
				e.printStackTrace();
				com.wm.util.JournalLogger.log(3, 90, 3, e);
				idm.put("error", e.getMessage());
			}
		
		}
		else{
			idm.put("error", "Unable to fetch service "+serviceName);
		}
			
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	
	public static void getFlowStepName(FlowElement flowElement,StringBuffer hasDisabledCode) 
	{
		if (flowElement.getFlowType().equals("SEQUENCE") || flowElement.getFlowType().equals("BRANCH") || flowElement.getFlowType().equals("LOOP") || flowElement.getFlowType().equals("RETRY")) {
			if (flowElement.getNodes() != null && flowElement.getNodes().length > 0) {
				for (FlowElement flowElement2 : flowElement.getNodes()) {
					if (!flowElement.isEnabled()) {
	
						hasDisabledCode.append("1");
	
					}
	
					getFlowStepName(flowElement2, hasDisabledCode);
					/*
					 * recursively calling the getFlowStepName method in case of
					 * sequences, branches, loops and retries as these steps can
					 * have more child steps
					 */
	
				}
			}
		} else {
	
			if (flowElement.getFlowType().equals("INVOKE") || flowElement.getFlowType().equals("MAP")) {
				if (!flowElement.isEnabled()) {
	
					hasDisabledCode.append("1");
	
				}
			}
	
		}
	}
	// --- <<IS-END-SHARED>> ---
}

