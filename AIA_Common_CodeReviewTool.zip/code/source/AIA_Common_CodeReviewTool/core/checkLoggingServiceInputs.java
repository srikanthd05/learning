package AIA_Common_CodeReviewTool.core;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.lang.flow.FlowElement;
import com.wm.lang.flow.FlowInvoke;
import com.wm.lang.flow.FlowMapCopy;
import com.wm.lang.flow.FlowMapSet;
import com.wm.lang.flow.FlowRoot;
import com.wm.lang.ns.NSName;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import com.softwareag.util.IDataMap;
import com.wm.app.b2b.server.BaseService;
import com.wm.app.b2b.server.ns.Namespace;
// --- <<IS-END-IMPORTS>> ---

public final class checkLoggingServiceInputs

{
	// ---( internal utility methods )---

	final static checkLoggingServiceInputs _instance = new checkLoggingServiceInputs();

	static checkLoggingServiceInputs _newInstance() { return new checkLoggingServiceInputs(); }

	static checkLoggingServiceInputs _cast(Object o) { return (checkLoggingServiceInputs)o; }

	// ---( server methods )---




	public static final void checkLoggingServiceInputs (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(checkLoggingServiceInputs)>> ---
		// @sigtype java 3.5
		// [i] field:0:required serviceName
		// [i] field:0:required loggingServiceName
		// [o] field:1:required mappings
		IDataMap idm = new IDataMap(pipeline);
		//System.out.println("****");
		String serviceName = idm.getAsString("serviceName");
		String loggingServiceName = idm.getAsString("loggingServiceName"); 
		List<String> loggingServiceMappings = new ArrayList<String>();
		BaseService baseService = Namespace.getService(NSName.create(serviceName));//Creating a baseService object to get a handle to the flow service.
		if(baseService!=null){
		try {
			
			IData serviceSteps = baseService.getAsData();   
			IDataCursor idc = serviceSteps.getCursor();
				if (baseService.getServiceType().toString().equals("flow/default")) {
		
					while (idc.next()) {
		
						if (idc.getKey().toString() == "flow") {
							FlowRoot fr = (FlowRoot) idc.getValue();
							FlowElement fe[] = fr.getNodes();
							if (fe != null && fe.length > 0) {
								for (FlowElement flowElement : fe) {
		
									getFlowStepName(flowElement, loggingServiceName,loggingServiceMappings);
		
								}
							}
						}
					}
		
					idc.destroy();
					
					idm.put("mappings", loggingServiceMappings.toArray(new String[loggingServiceMappings.size()]));
		
				}
		
				else {
					idm.put("error", serviceName + " is not a flow service.");
				}
			} catch (Exception e) {
				e.printStackTrace();
				com.wm.util.JournalLogger.log(3, 90, 3, e);
				idm.put("error", e.getMessage());
			}
		
		}
		else{
			idm.put("error", "Unable to fetch service "+serviceName);
		}
		
			
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	public static void getFlowStepName(FlowElement flowElement,String loggingServiceName, List<String> loggingServiceMappings) 
	{ // System.out.println("*"+flowElement.getFlowType()+"*");
		if (flowElement.getFlowType().equals("SEQUENCE") || flowElement.getFlowType().equals("BRANCH")
				|| flowElement.getFlowType().equals("LOOP") || flowElement.getFlowType().equals("RETRY")) {
			if (flowElement.getNodes() != null && flowElement.getNodes().length > 0) {
				for (FlowElement flowElement2 : flowElement.getNodes()) {
	
					getFlowStepName(flowElement2, loggingServiceName, loggingServiceMappings);
	
				}
			}
	
		}
	
		else {
			if (flowElement.getFlowType().equals("INVOKE")) {
				FlowInvoke flowInvokeElement = (FlowInvoke) flowElement;
				// System.out.println(flowInvokeElement.getService().toString());
				if (flowInvokeElement.getService().toString().equals(loggingServiceName)) {
	
					if (flowInvokeElement.getInputMap() != null) {
						if (flowInvokeElement.getInputMap().getCopyMaps() != null) {
	
							for (FlowMapCopy copyMap : flowInvokeElement.getInputMap().getCopyMaps()) {
	
								loggingServiceMappings.add("From:" + copyMap.getParsedFrom().getPathDisplayString()
										+ "  To:" + copyMap.getParsedTo().getPathDisplayString());
							}
						}
	
						if (flowInvokeElement.getInputMap().getSetMaps() != null) {
							for (FlowMapSet setMap : flowInvokeElement.getInputMap().getSetMaps()) {
	
								loggingServiceMappings.add("\"" + setMap.getInput().toString() + "\"" + "  To:"
										+ setMap.getParsedPath().getPathDisplayString());
							}
	
						}
	
					}
	
				}
			}
	
		}
	
	}
	// --- <<IS-END-SHARED>> ---
}

