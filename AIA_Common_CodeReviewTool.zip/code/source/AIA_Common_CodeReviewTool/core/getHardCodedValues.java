package AIA_Common_CodeReviewTool.core;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.lang.flow.FlowElement;
import com.wm.lang.flow.FlowInvoke;
import com.wm.lang.flow.FlowMap;
import com.wm.lang.flow.FlowMapInvoke;
import com.wm.lang.flow.FlowMapSet;
import com.wm.lang.flow.FlowRoot;
import com.wm.lang.ns.NSName;
import com.wm.util.JournalLogger;
import java.util.ArrayList;
import java.util.List;
import com.softwareag.util.IDataMap;
import com.wm.app.b2b.server.BaseService;
import com.wm.app.b2b.server.ns.Namespace;
// --- <<IS-END-IMPORTS>> ---

public final class getHardCodedValues

{
	// ---( internal utility methods )---

	final static getHardCodedValues _instance = new getHardCodedValues();

	static getHardCodedValues _newInstance() { return new getHardCodedValues(); }

	static getHardCodedValues _cast(Object o) { return (getHardCodedValues)o; }

	// ---( server methods )---




	public static final void getHardCodedValues (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getHardCodedValues)>> ---
		// @sigtype java 3.5
		// [i] field:0:required serviceName
		// [o] field:1:required hardCodedValues
		IDataMap idm = new IDataMap(pipeline);
		String serviceName = idm.getAsString("serviceName");
		List<String> hardCodedVlauesList = new ArrayList<String>();
		BaseService baseService = Namespace.getService(NSName.create(serviceName));
		//idm.put("service", baseService);
		if (baseService != null)
		{
			try {
					IData serviceSteps = baseService.getAsData();
					IDataCursor idc = serviceSteps.getCursor();
					//services d1 = new services();
					if (baseService.getServiceType().toString().equals("flow/default")) 
					{
						while (idc.next()) 
						{
							if (idc.getKey().toString() == "flow") 
							{
								FlowRoot fr = (FlowRoot) idc.getValue();
								//com.wm.util.JournalLogger.log(3, 90, 3, "fr obtained");
								FlowElement fe[] = fr.getNodes();
								//com.wm.util.JournalLogger.log(3, 90, 3, "fr.getNodes");
								if(fe!=null && fe.length>0)
								{
									for (FlowElement flowElement : fe) 
									{ 						
										//com.wm.util.JournalLogger.log(3, 90, 3, "in first for");
										getMapSets(flowElement,hardCodedVlauesList);
									}
								}
							}
						}
						
						idc.destroy();
						idm.put("hardCodedValues",hardCodedVlauesList.toArray(new String[hardCodedVlauesList.size()]) );
					} 
					else 
					{
						idm.put("error", serviceName + " is not a flow service.");
					}
				} 
			catch (Exception e) 
			{
				e.printStackTrace();
				com.wm.util.JournalLogger.log(3, 90, 3, e);
				idm.put("error", e.getMessage());
			}
		} 
		else
		{
			idm.put("error", "Unable to fetch flow service " + serviceName);
		}
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	public static void getMapSets(FlowElement flowElement, List<String> hardCodedVlauesList) 
	 {
		if (flowElement.getFlowType().equals("SEQUENCE")
				|| flowElement.getFlowType().equals("BRANCH")
				|| flowElement.getFlowType().equals("LOOP")
				|| flowElement.getFlowType().equals("RETRY")) 
		{
			//JournalLogger.log(3, 90, 3, "in if for sblr");
			if(flowElement.getNodes()!=null && flowElement.getNodes().length>0)
			{
				for (FlowElement flowElement2 : flowElement.getNodes())
				{
					//JournalLogger.log(3,90,3, flowElement2.getDisplayType());
					
					getMapSets(flowElement2, hardCodedVlauesList);
					
					/*	recursively calling the getFlowStepName method in case of sequences, 
					branches, loops and retries as these steps
					can have more child steps*/
				}
			}
		} 
		else 
		{
			if (flowElement.getFlowType().equals("MAP")) 
			{				
				FlowMap flowMap = (FlowMap) flowElement;
				if(flowMap.getSetMaps()!=null && flowMap.getSetMaps().length >0 )
				{
					for (FlowMapSet mapset : flowMap.getSetMaps()) 
					{
						if(mapset.getInput() !=null && mapset.getInput().toString().trim().length()>0 ){
							hardCodedVlauesList.add(mapset.getParsedPath().getPathDisplayString()+"<--"+mapset.getInput().toString());
						}
						
					}
				}
				
				
				if(flowMap.getInvokeMaps()!=null &&flowMap.getInvokeMaps().length>0){
					//System.out.println(flowMap.getInvokeMaps().toString());
					for(FlowMapInvoke transformers : flowMap.getInvokeMaps()){
						
						if(transformers.getInputMap().getSetMaps() != null && transformers.getInputMap().getSetMaps().length>0){
							for (FlowMapSet mapset : transformers.getInputMap().getSetMaps()) 
							{
								if(mapset.getInput() !=null && mapset.getInput().toString().trim().length()>0){
									hardCodedVlauesList.add(mapset.getParsedPath().getPathDisplayString()+"<--"+mapset.getInput().toString());
								}
							}
							
							
						}
					}
				}
				
				
				
			}
			if (flowElement.getFlowType().equals("INVOKE")) 
			{				
				FlowInvoke flowInvoke = (FlowInvoke) flowElement;
				//JournalLogger.log(3, 90, 3, flowInvoke.getService().toString());
				//JournalLogger.log(3, 90, 3, flowInvoke.getInputMap());
				if(flowInvoke.getInputMap() != null){
				if(flowInvoke.getInputMap().getSetMaps()!=null && flowInvoke.getInputMap().getSetMaps().length>0)
				{
					for (FlowMapSet mapset : flowInvoke.getInputMap().getSetMaps())
					{
						if(mapset.getInput() !=null && mapset.getInput().toString().trim().length()>0 ){
							hardCodedVlauesList.add(mapset.getParsedPath().getPathDisplayString()+"<--"+mapset.getInput().toString());
						}
					}
				}
				}
			}
		}
	}
	// --- <<IS-END-SHARED>> ---
}

