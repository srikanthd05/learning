self.__precacheManifest = [
  {
    "revision": "e6f2d0a22525928184a4d0bb33907189",
    "url": "/KFT/img/logo.e6f2d0a2.png"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/KFT/robots.txt"
  },
  {
    "revision": "ad538a69b0e8615ed0419c4529344ffc",
    "url": "/KFT/fonts/Roboto-Thin.ad538a69.woff2"
  },
  {
    "revision": "0320afb93c9c23425a95",
    "url": "/KFT/js/chunk-vendors.8b723f43.js"
  },
  {
    "revision": "e0de9891f53f0f022c53",
    "url": "/KFT/js/configuration.adcbb463.js"
  },
  {
    "revision": "a112c14c4a8226c16995",
    "url": "/KFT/js/monitor.36342597.js"
  },
  {
    "revision": "72a2d9464d5b2e4211d3",
    "url": "/KFT/js/configuration~monitor.ab3caf16.js"
  },
  {
    "revision": "73f0a88bbca1bec19fb1303c689d04c6",
    "url": "/KFT/fonts/Roboto-Regular.73f0a88b.woff2"
  },
  {
    "revision": "19789393c7b436fe63a9",
    "url": "/KFT/js/app.7de4502b.js"
  },
  {
    "revision": "90d1676003d9c28c04994c18bfd8b558",
    "url": "/KFT/fonts/Roboto-Medium.90d16760.woff2"
  },
  {
    "revision": "bd52a727b5449dc3f8195b72c9c58341",
    "url": "/KFT/fonts/fa-regular-400.bd52a727.woff2"
  },
  {
    "revision": "377f6826c7cb5dc99b6f3dabe21d2704",
    "url": "/KFT/index.html"
  },
  {
    "revision": "58b03898e49a32830a20195ef1db6eb4",
    "url": "/KFT/img/nosearch.58b03898.png"
  },
  {
    "revision": "6fc17b0264d625675f54ce46f65fe6f5",
    "url": "/KFT/img/loading.6fc17b02.png"
  },
  {
    "revision": "2cd2be177470d5096992572176bbe76e",
    "url": "/KFT/fonts/fa-solid-900.2cd2be17.woff2"
  },
  {
    "revision": "5fec8b0f3c71d4df77b19fbb818261b7",
    "url": "/KFT/img/nodata.5fec8b0f.png"
  },
  {
    "revision": "657a469469a2fc38a2901c68a3d56512",
    "url": "/KFT/fonts/fa-solid-900.657a4694.woff"
  },
  {
    "revision": "fdc155d57b7351ef85b3028ea3cfc048",
    "url": "/KFT/img/fa-solid-900.fdc155d5.svg"
  },
  {
    "revision": "f249e44df3044e7b0d665b550569ddf0",
    "url": "/KFT/img/fa-brands-400.f249e44d.svg"
  },
  {
    "revision": "a547e21eceadf53602caf057be9ad9fd",
    "url": "/KFT/fonts/fa-solid-900.a547e21e.eot"
  },
  {
    "revision": "5ee32f5c8598e1a63ddf1aad4ffe54f4",
    "url": "/KFT/fonts/fa-solid-900.5ee32f5c.ttf"
  },
  {
    "revision": "2fad4ee0a47f41bc76e21c2baf613182",
    "url": "/KFT/img/fa-regular-400.2fad4ee0.svg"
  },
  {
    "revision": "94008e69aaf05da75c0bbf8f8bb0db41",
    "url": "/KFT/fonts/Roboto-BoldItalic.94008e69.woff2"
  },
  {
    "revision": "f2e186cfab4787d4ef6f1bb192aa9a1b",
    "url": "/KFT/fonts/fa-brands-400.f2e186cf.ttf"
  },
  {
    "revision": "a03df7ab0ffc96cabbfe3dc71c60baaa",
    "url": "/KFT/fonts/fa-regular-400.a03df7ab.eot"
  },
  {
    "revision": "f861a57c52ef711cf807a3eec92c0e17",
    "url": "/KFT/fonts/fa-brands-400.f861a57c.woff2"
  },
  {
    "revision": "2cd8d991e82712f1a5c5de8ee869ca74",
    "url": "/KFT/fonts/fa-regular-400.2cd8d991.ttf"
  },
  {
    "revision": "7ab2cb050690f93994c46258d49af5b6",
    "url": "/KFT/fonts/fa-regular-400.7ab2cb05.woff"
  },
  {
    "revision": "c73eb1ceba3321a80a0aff13ad373cb4",
    "url": "/KFT/fonts/Roboto-Light.c73eb1ce.woff"
  },
  {
    "revision": "a112c14c4a8226c16995",
    "url": "/KFT/css/monitor.7556c8e0.css"
  },
  {
    "revision": "457cb96b6191ed105c4fe8463957f70d",
    "url": "/KFT/fonts/fa-brands-400.457cb96b.woff"
  },
  {
    "revision": "cc2fadc3928f2f223418887111947b40",
    "url": "/KFT/fonts/Roboto-BlackItalic.cc2fadc3.woff"
  },
  {
    "revision": "b52fac2bb93c5858f3f2675e4b52e1de",
    "url": "/KFT/fonts/Roboto-Bold.b52fac2b.woff2"
  },
  {
    "revision": "59eb3601394dd87f30f82433fb39dd94",
    "url": "/KFT/fonts/Roboto-Black.59eb3601.woff2"
  },
  {
    "revision": "5b4a33e176ff736a74f0ca2dd9e6b396",
    "url": "/KFT/fonts/Roboto-ThinItalic.5b4a33e1.woff2"
  },
  {
    "revision": "e8eaae902c3a4dacb9a5062667e10576",
    "url": "/KFT/fonts/Roboto-LightItalic.e8eaae90.woff2"
  },
  {
    "revision": "4357beb823a5f8d65c260f045d9e019a",
    "url": "/KFT/fonts/Roboto-RegularItalic.4357beb8.woff2"
  },
  {
    "revision": "13ec0eb5bdb821ff4930237d7c9f943f",
    "url": "/KFT/fonts/Roboto-MediumItalic.13ec0eb5.woff2"
  },
  {
    "revision": "3165b14bbf3b64fca65829ecde6b800d",
    "url": "/KFT/fonts/fa-brands-400.3165b14b.eot"
  },
  {
    "revision": "f75569f8a5fab0893fa712d8c0d9c3fe",
    "url": "/KFT/fonts/Roboto-BlackItalic.f75569f8.woff2"
  },
  {
    "revision": "d3b47375afd904983d9be8d6e239a949",
    "url": "/KFT/fonts/Roboto-Thin.d3b47375.woff"
  },
  {
    "revision": "d26871e8149b5759f814fd3c7a4f784b",
    "url": "/KFT/fonts/Roboto-Light.d26871e8.woff2"
  },
  {
    "revision": "35b07eb2f8711ae08d1f58c043880930",
    "url": "/KFT/fonts/Roboto-Regular.35b07eb2.woff"
  },
  {
    "revision": "1d6594826615607f6dc860bb49258acb",
    "url": "/KFT/fonts/Roboto-Medium.1d659482.woff"
  },
  {
    "revision": "50d75e48e0a3ddab1dd15d6bfb9d3700",
    "url": "/KFT/fonts/Roboto-Bold.50d75e48.woff"
  },
  {
    "revision": "313a65630d341645c13e4f2a0364381d",
    "url": "/KFT/fonts/Roboto-Black.313a6563.woff"
  },
  {
    "revision": "8a96edbbcd9a6991d79371aed0b0288e",
    "url": "/KFT/fonts/Roboto-ThinItalic.8a96edbb.woff"
  },
  {
    "revision": "13efe6cbc10b97144a28310ebdeda594",
    "url": "/KFT/fonts/Roboto-LightItalic.13efe6cb.woff"
  },
  {
    "revision": "f5902d5ef961717ed263902fc429e6ae",
    "url": "/KFT/fonts/Roboto-RegularItalic.f5902d5e.woff"
  },
  {
    "revision": "83e114c316fcc3f23f524ec3e1c65984",
    "url": "/KFT/fonts/Roboto-MediumItalic.83e114c3.woff"
  },
  {
    "revision": "4fe0f73cc919ba2b7a3c36e4540d725c",
    "url": "/KFT/fonts/Roboto-BoldItalic.4fe0f73c.woff"
  },
  {
    "revision": "72a2d9464d5b2e4211d3",
    "url": "/KFT/css/configuration~monitor.36ffa4a1.css"
  },
  {
    "revision": "e0de9891f53f0f022c53",
    "url": "/KFT/css/configuration.af586315.css"
  },
  {
    "revision": "0320afb93c9c23425a95",
    "url": "/KFT/css/chunk-vendors.e0a9e40f.css"
  }
];