package KFT.utils;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
// --- <<IS-END-IMPORTS>> ---

public final class exception

{
	// ---( internal utility methods )---

	final static exception _instance = new exception();

	static exception _newInstance() { return new exception(); }

	static exception _cast(Object o) { return (exception)o; }

	// ---( server methods )---




	public static final void throwServiceException (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(throwServiceException)>> ---
		// @sigtype java 3.5
		// [i] field:0:required errorMessage
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	errorMessage = IDataUtil.getString( pipelineCursor, "errorMessage" );
		pipelineCursor.destroy();
		
		throw new ServiceException(errorMessage);
		
		// pipeline
		
			
		// --- <<IS-END>> ---

                
	}
}

