package KFT.utils;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.softwareag.util.IDataMap;
import com.wm.util.*;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
// --- <<IS-END-IMPORTS>> ---

public final class file

{
	// ---( internal utility methods )---

	final static file _instance = new file();

	static file _newInstance() { return new file(); }

	static file _cast(Object o) { return (file)o; }

	// ---( server methods )---




	public static final void fileExists (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(fileExists)>> ---
		// @sigtype java 3.5
		// [i] field:0:required checkFileName
		// [o] field:0:required status
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	checkFileName = IDataUtil.getString( pipelineCursor, "checkFileName" );
		pipelineCursor.destroy();
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		//File f=null;
		String status = null;
		boolean fileExists = false;
		try{
			
			fileExists = new File(checkFileName).exists();
		    if(fileExists)
		    	IDataUtil.put( pipelineCursor_1, "status", "true" );
		    else
		    	IDataUtil.put( pipelineCursor_1, "status", "false" );
			
		}catch(Exception e){
			IDataUtil.put( pipelineCursor_1, "status", "false" );
		}
		
		// pipeline
		
		
		pipelineCursor_1.destroy();
		
			
		// --- <<IS-END>> ---

                
	}



	public static final void listFiles (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(listFiles)>> ---
		// @sigtype java 3.5
		// [i] field:0:required dirName
		// [i] field:0:required filePattern
		// [o] field:1:required fileList
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	dirName = IDataUtil.getString( pipelineCursor, "dirName" );
		String	filePattern = IDataUtil.getString( pipelineCursor, "filePattern" );
		pipelineCursor.destroy();
		IDataCursor pipelineCursor_1 = pipeline.getCursor();	
		
		
			try{
			
				// pipeline
			
			
			    File directory = new File(dirName);
			    File[] fList = directory.listFiles();
			   
		        //get all the files from a directory
			   /* if(filePattern.isEmpty() || filePattern.equals(null)){
			    	fList = directory.listFiles();
			    }else{
			    	fList = directory.listFiles(new FilenameFilter() {
			            @Override
			            public boolean accept(File dir, String name) {
			                return name.matches(filePattern);
			            }
			        });
			    }
		        */
		        ArrayList<String> files = new ArrayList<String>();
		        //String[] listOfFiles = null;
		        IDataUtil.put( pipelineCursor_1, "fileSize", fList.length );
		        //int i = 1;
		        
		        for (File file : fList){
		        	
		            if (file.isDirectory()){
		            	
		                //System.out.println(file.getName());
		            }else{
		            	files.add(file.getName());
		            }
		            
		        }
		
			// pipeline
			
		        IDataUtil.put( pipelineCursor_1, "fileList", files.toArray(new String[0]) ); 
		}catch(Exception e){
			IDataUtil.put( pipelineCursor_1, "errorMessage", e.getStackTrace() );
		}
				
		
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void makeDir (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(makeDir)>> ---
		// @sigtype java 3.5
		// [i] field:0:required dirName
		// [o] field:0:required result
		// [o] field:0:required dirExist
		String result = null;
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	dirName = IDataUtil.getString( pipelineCursor, "dirName" );
		pipelineCursor.destroy();
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		try{
		// pipeline
		File file = new File(dirName);
		if(file.exists()){
			result = dirName + " already exist";
		}else{
			file.mkdir();
			result = dirName + " created successfully";
		}
		
		}catch(Exception e){
			result = e.getMessage();
		}
		
		IDataUtil.put( pipelineCursor_1, "result", result );		
		pipelineCursor_1.destroy();
		
			
		// --- <<IS-END>> ---

                
	}



	public static final void moveFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(moveFile)>> ---
		// @sigtype java 3.5
		// [i] field:0:required sourceFileName
		// [i] field:0:required targetFileName
		// [o] field:0:required errorMessage
		// [o] field:0:required status
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	sourceFileName = IDataUtil.getString( pipelineCursor, "sourceFileName" );
			String	targetFileName = IDataUtil.getString( pipelineCursor, "targetFileName" );
		pipelineCursor.destroy();
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		try{
						
			Files.move(Paths.get(sourceFileName), Paths.get(targetFileName), StandardCopyOption.REPLACE_EXISTING);
			IDataUtil.put( pipelineCursor_1, "status", "true" );
			
		}catch(Exception e){
			IDataUtil.put( pipelineCursor_1, "status", "false" );
			IDataUtil.put( pipelineCursor_1, "errorMessage", e.getMessage() );
			
		}
		
		// pipeline
		
		
		
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void removeFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(removeFile)>> ---
		// @sigtype java 3.5
		// [i] field:0:required removeFileName
		// [o] field:0:required status
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	removeFileName = IDataUtil.getString( pipelineCursor, "removeFileName" );
		pipelineCursor.destroy();
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		
		try{
		
			File f = new File(removeFileName);
			
			if(f.delete())
					IDataUtil.put( pipelineCursor_1, "status", "success" );
					else
						IDataUtil.put( pipelineCursor_1, "status", "failed" );
		
			
		}catch(Exception e){
			IDataUtil.put( pipelineCursor_1, "status", "failed" );
		}
		
		// pipeline
		
		
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void stringToFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(stringToFile)>> ---
		// @sigtype java 3.5
		// [i] field:0:required fileName
		// [i] field:0:required data
		try{
		
			// pipeline
			IDataCursor pipelineCursor = pipeline.getCursor();
				String	fileName = IDataUtil.getString( pipelineCursor, "fileName" );
				String	data = IDataUtil.getString( pipelineCursor, "data" );
			pipelineCursor.destroy();
		
			// pipeline
		
			FileWriter fstream = new FileWriter( fileName );
		    BufferedWriter out = new BufferedWriter(fstream);
		out.write(data);
		//Close the output stream
		out.close();
			
		}catch(Exception e){}
		// --- <<IS-END>> ---

                
	}



	public static final void writeFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(writeFile)>> ---
		// @sigtype java 3.5
		// [i] field:0:required fileName
		// [i] field:0:required content
		String fileContent = "";
		String fileName = "";
		//String status ="success";
		FileWriter fileWriter = null;
		IDataMap p = new IDataMap(pipeline);
		fileContent = p.getAsString("content");
		fileName = p.getAsString("fileName");
		
		try {
			fileWriter = new FileWriter(fileName); //("D:/test/file.txt");
			//inherited method from java.io.OutputStreamWriter 
			fileWriter.write(fileContent); //("TEST Data");
		} catch (Exception e) {
			throw new ServiceException("File Write Error - "+e);
		}finally {
			try {
				if (fileWriter != null) {
					fileWriter.flush();
					fileWriter.close();					
				}
			} catch (IOException e) {
				throw new ServiceException("File Write Error - "+e);
			}
		}
		// --- <<IS-END>> ---

                
	}
}

