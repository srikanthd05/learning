package CG510_SupportServices_v1.services;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2018-05-09 12:34:48 CEST
// -----( ON-HOST: itsbebelsp00272.jnj.com

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
// --- <<IS-END-IMPORTS>> ---

public final class util

{
	// ---( internal utility methods )---

	final static util _instance = new util();

	static util _newInstance() { return new util(); }

	static util _cast(Object o) { return (util)o; }

	// ---( server methods )---




	public static final void getDates (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getDates)>> ---
		// @sigtype java 3.5
		// [o] field:0:required fromDate
		// [o] field:0:required toDate
		try{
		String fromDate="";
		String toDate="";
		toDate= new SimpleDateFormat("dd-MMM-yy").format(new Date());
		Calendar lastMonth = Calendar.getInstance();
		lastMonth.add(Calendar.MONTH, -1);
		fromDate= new SimpleDateFormat("dd-MMM-yy").format(lastMonth.getTime());
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "fromDate", fromDate );
		IDataUtil.put( pipelineCursor_1, "toDate", toDate );
		pipelineCursor_1.destroy();
		}catch(Exception e){
			throw new ServiceException(e.getMessage());
		}
			
		// --- <<IS-END>> ---

                
	}



	public static final void listFilesFromFolder (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(listFilesFromFolder)>> ---
		// @sigtype java 3.5
		// [i] field:0:required dirPath
		// [o] record:1:required listOfFiles
		// [o] - field:0:required fileName
		// [o] - field:0:required fileSize
		// [o] - field:0:required lastModified
		// [o] field:0:required errorMessage
		// [o] field:0:required numberOfFiles
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	dirPath = IDataUtil.getString( pipelineCursor, "dirPath" );
		
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		
		try{
		File file=new File(dirPath);
		if(!file.isDirectory()){
			throw new ServiceException("Directory not found");
			
		}
		File[] files=file.listFiles();			
		//File[] files_only = null;
		
		ArrayList list = new ArrayList();
		
		
		if(file.length() == 0 ){				
			
		}else{
			//int j=0;
			for (int i=0; i< files.length; i++){					
				if(files[i].isFile()){
					System.out.println(files[i]);
					list.add(files[i]);
				}
			}
			
			
		}
		
		
		if(list.size() == 0 ){
			IDataUtil.put( pipelineCursor_1, "numberOfFiles", "0"  );
			
		}else{
			//System.out.println("number of files in the list" + list.size() );
			IDataUtil.put( pipelineCursor_1, "numberOfFiles", Integer.toString(list.size())  );
			IData[]	listOfFiles = new IData[list.size()];
			for( int i=0;i< list.size();i++){
			listOfFiles[i] = IDataFactory.create();
			IDataCursor listOfFilesCursor = listOfFiles[i].getCursor();
			File newFile = (File)list.get(i);
			IDataUtil.put( listOfFilesCursor, "fileName", newFile.getName() );
			IDataUtil.put( listOfFilesCursor, "fileSize", newFile.length()+" Bytes" );
			IDataUtil.put( listOfFilesCursor, "lastModified", new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(newFile.lastModified()) );
			listOfFilesCursor.destroy();
			IDataUtil.put( pipelineCursor_1, "listOfFiles", listOfFiles );
			}
		}
		//listOfFiles.
		
		}catch(Exception e){
		IDataUtil.put( pipelineCursor_1, "errorMessage", e.getMessage() );
		
		}
		// listOfFiles
		
		pipelineCursor_1.destroy();
		
			
		// --- <<IS-END>> ---

                
	}
}

